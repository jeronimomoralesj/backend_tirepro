import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // ✅ Ensure all API routes are prefixed with /api
  app.setGlobalPrefix('api');

  // ✅ Enable CORS so Next.js (Frontend) can talk to NestJS (Backend)
  app.enableCors({
    origin: "http://localhost:3000",
    credentials: true,
  });

  await app.listen(5001);
}
bootstrap();
